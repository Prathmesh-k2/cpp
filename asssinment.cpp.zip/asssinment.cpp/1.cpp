#include<iostream>
using namespace std;
int add(int x, int y){
return x+y;
}
int sub(int x, int y){
return x-y;
}
int multipliction(int x, int y){
return x*y;
}
int divied(int x, int y){
return x/y;
}
int main(){
    int a,b;
    cout<<"Enter the number";
    cin>>a>>b;
   
    cout<<add(a,b);
    cout<<endl;
    cout<<sub(a,b);
    cout<<endl;
    cout<<multipliction(a,b);
    cout<<endl;
    cout<<divied(a,b);

}