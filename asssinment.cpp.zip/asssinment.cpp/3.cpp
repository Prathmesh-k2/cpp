#include<iostream>
using namespace std;
int multiplicationtable(int n){
for(int i=1;i<=10;i++){
    cout<<i<<" x "<<n<<" = "<<i*n<<endl;
}
    cout<<endl;
}
int main(){
    int num;
    cout <<"Enter the number";
    cin>>num;
    cout<<multiplicationtable(num);
}