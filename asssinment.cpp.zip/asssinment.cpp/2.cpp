#include<iostream>
using namespace std;
int main ()
{
    int a,b,c;
    cout<<"Enterthe three number :";
    cin>>a>>b>>c;
  if(b<=a){
    if(c<=a){
      cout<<" A is largest number :"<<a;
    }
    else{
        cout<<" C is largest number :"<<c;
    }
    }
else{
    if(c<=b){
         cout<<" B is largest number :"<<b;
    }
    else{
        cout<<" C is largest number :"<<c;
    }
    }
}
  